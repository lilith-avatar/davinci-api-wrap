---@class TextureRef
local TextureRef = {}
---@return boolean
function TextureRef:IsNull() end
return TextureRef