---@class AlphaGradient
local AlphaGradient = {}
AlphaGradient.Alpha = 0
AlphaGradient.Mode = 0
return AlphaGradient