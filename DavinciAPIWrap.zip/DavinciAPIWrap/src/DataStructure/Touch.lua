---@class Touch
local Touch = {}

Touch.DeltaPosition = Vector2(0,0)
Touch.Phase = Enum.TouchPhase.Began
Touch.Position = Vector2(0,0)

return Touch