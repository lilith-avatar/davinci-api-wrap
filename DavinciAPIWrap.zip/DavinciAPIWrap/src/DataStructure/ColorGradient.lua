---@class ColorGradient
local ColorGradient = {}
ColorGradient.Color = Color(0,0,0,0)
ColorGradient.ColorKeys = {}
return ColorGradient