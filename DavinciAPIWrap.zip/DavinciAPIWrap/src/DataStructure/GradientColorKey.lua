---@class GradientColorKey
local GradientColorKey = {}
GradientColorKey.Color = Color(0,0,0,0)
GradientColorKey.Time = 0
return GradientColorKey