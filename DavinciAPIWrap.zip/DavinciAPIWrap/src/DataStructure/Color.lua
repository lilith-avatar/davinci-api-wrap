---@param R number
---@param G number
---@param B number
---@param A number
Color = function(R, G, B, A)
    ---@type Color
    local re
    return re
end

---@class Color
local Color = {}

Color.A = 0
Color.R = 0
Color.G = 0
Color.B = 0
Color.a = 0
Color.r = 0
Color.g = 0
Color.b = 0

return Color