---@class MinMaxCurveVector3
local MinMaxCurveVector3 = {}
---@type MinMaxCurve
MinMaxCurveVector3.CurveX = nil
---@type MinMaxCurve
MinMaxCurveVector3.CurveY = nil
---@type MinMaxCurve
MinMaxCurveVector3.CurveZ = nil
MinMaxCurveVector3.Mode = 0
return MinMaxCurveVector3

