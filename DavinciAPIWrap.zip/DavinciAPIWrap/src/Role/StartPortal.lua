---@class StartPortal:Object
local StartPortal = {}
---出生点矩形区域的长度。
StartPortal.Length = 0

---出生点矩形区域的宽度。
StartPortal.Width = 0

return StartPortal