---@class MinMaxCurveVector2
local MinMaxCurveVector2 = {}
---@type MinMaxCurve
MinMaxCurveVector2.CurveX = nil
---@type MinMaxCurve
MinMaxCurveVector2.CurveY = nil
MinMaxCurveVector2.Mode = 0
return MinMaxCurveVector2

