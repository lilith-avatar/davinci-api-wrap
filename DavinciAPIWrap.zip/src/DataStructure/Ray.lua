---@param origin Vector3
---@param direction Vector3
Ray = function(origin, direction)
    ---@type Ray
    local re
    return re
end

---@class Ray
local Ray = {}
Ray.Direction = Vector3.Zero
Ray.Origin = Vector3.Zero
---@param distance number
function  Ray:GetPoint(distance) end
return Ray
