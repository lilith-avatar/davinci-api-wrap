---@class StringDropdown
local StringDropdown = {}
StringDropdown.AttriValue = ''
StringDropdown.ValueList = {}

return StringDropdown
