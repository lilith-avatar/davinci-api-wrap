---@class MinMaxCurve
local MinMaxCurve = {}
MinMaxCurve.ForceMinY = 0
MinMaxCurve.Max = 0
MinMaxCurve.Min = 0
MinMaxCurve.Mode = 0
MinMaxCurve.MultiplyY = 0
MinMaxCurve.TimeList = {}
MinMaxCurve.ValueList = {}

return MinMaxCurve
