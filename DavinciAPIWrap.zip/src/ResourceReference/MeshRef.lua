---@class MeshRef
local MeshRef = {}
---@return boolean
function MeshRef:IsNull() end
return MeshRef