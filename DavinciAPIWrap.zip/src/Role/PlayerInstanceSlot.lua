---@class PlayerInstanceSlot:Object
local PlayerInstanceSlot = {}
---@type Object
PlayerInstanceSlot.Archetype = nil
return PlayerInstanceSlot