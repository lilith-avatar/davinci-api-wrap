---@class NpcAvatarInstance:PlayerAvatarInstance

local NpcAvatarInstance = {}


return NpcAvatarInstance
